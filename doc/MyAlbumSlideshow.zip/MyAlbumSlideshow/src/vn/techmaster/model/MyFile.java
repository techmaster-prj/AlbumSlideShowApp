package vn.techmaster.model;

public class MyFile {
	private String name;
	private String icon;
	private String properties;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	
}
