/** Automatically generated file. DO NOT MODIFY */
package vn.techmaster.myalbumslideshow;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}